# hotel
I developed this hotel website using HTML CSS and javascript
